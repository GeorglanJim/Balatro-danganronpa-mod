
SMODS.Joker{ --Kiyondo Ishida
    key = "kiyondoishida",
    config = {
        extra = {
            Mondo = 100
        }
    },
    loc_txt = {
        ['name'] = 'Kiyondo Ishida',
        ['text'] = {
            [1] = '{C:blue}+100 Chips{} Increases by',
            [2] = '{C:blue}+20{} every round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["danganro_mycustom_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            
            or args.source == 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and G.GAME.pool_flags.danganro_Kiyondo
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Mondo}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.Mondo
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                func = function()
                    card.ability.extra.Mondo = (card.ability.extra.Mondo) + 20
                    return true
                end
            }
        end
    end
}