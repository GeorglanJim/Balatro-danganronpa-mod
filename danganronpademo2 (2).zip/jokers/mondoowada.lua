
SMODS.Joker{ --Mondo Owada
    key = "mondoowada",
    config = {
        extra = {
            Taka = 200
        }
    },
    loc_txt = {
        ['name'] = 'Mondo Owada',
        ['text'] = {
            [1] = '{C:blue}+200 Chips{} reduces by',
            [2] = '{C:blue}-20 Chips{} every round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["danganro_mycustom_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Taka}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.Taka
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                func = function()
                    card.ability.extra.Taka = math.max(0, (card.ability.extra.Taka) - 20)
                    return true
                end
            }
        end
    end
}