
SMODS.Joker{ --Mukuro Ikusaba
    key = "mukuroikusaba",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Mukuro Ikusaba',
        ['text'] = {
            [1] = '{C:red}+100 Mult{} {C:blue}+200 Chips{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["danganro_mycustom_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            
            or args.source == 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and G.GAME.pool_flags.danganro_Junko
    end
}