
SMODS.Joker{ --Leon Kuwata
    key = "leonkuwata",
    config = {
        extra = {
            repetitions = 15,
            mult0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Leon Kuwata',
        ['text'] = {
            [1] = '{C:red}+1 Mult{} {C:red}+1 Mult{} {C:red}+1 Mult{} {C:red}+1 Mult{}',
            [2] = '{C:red}+1 Mult{} {C:red}+1 Mult{} {C:red}+1 Mult{} {C:red}+1 Mult{}',
            [3] = '{C:red}+1 Mult{} {C:red}+1 Mult{} {C:red}+1 Mult{} {C:red}+1 Mult{}',
            [4] = '{C:red}+1 Mult{} {C:red}+1 Mult{} {C:red}+1 Mult{} {C:red}+1 Mult{}',
            [5] = ''
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["danganro_mycustom_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                for i = 1, 15 do
                    SMODS.calculate_effect({mult = 1}, card)
                end
            end
        end
    end
}