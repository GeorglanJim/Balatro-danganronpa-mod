
SMODS.Joker{ --Kyoko Kirigiri
    key = "kyokokirigiri",
    config = {
        extra = {
            variable1 = 0,
            variable2 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Kyoko Kirigiri',
        ['text'] = {
            [1] = 'For every {C:attention}8{} {C:inactive}(8){} sold {C:attention}Joker{}',
            [2] = 'Gain {X:red,C:white}x1{} ({X:red,C:white}x1{} Currently)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["danganro_mycustom_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.variable1, card.ability.extra.variable2}}
    end,
    
    calculate = function(self, card, context)
        if context.selling_card  then
            if to_big((card.ability.extra.variable1 or 0)) == to_big(8) then
                return {
                    func = function()
                        card.ability.extra.variable2 = (card.ability.extra.variable2) + 1
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.variable1 = 0
                            return true
                        end,
                        colour = G.C.BLUE
                    }
                }
            else
                return {
                    func = function()
                        card.ability.extra.variable1 = (card.ability.extra.variable1) + 1
                        return true
                    end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.variable2
            }
        end
    end
}