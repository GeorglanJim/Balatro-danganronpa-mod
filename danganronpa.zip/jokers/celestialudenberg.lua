
SMODS.Joker{ --Celestia Ludenberg
    key = "celestialudenberg",
    config = {
        extra = {
            chips0 = 40,
            odds = 2,
            mult0 = 20,
            odds2 = 2,
            dollars0 = 10,
            odds3 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Celestia Ludenberg',
        ['text'] = {
            [1] = '{C:green}1 in 2 chance{} to either give',
            [2] = '{C:attention}10${} {C:red}+20 Mult{} or {C:blue}40 Chips{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["danganro_mycustom_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_danganro_celestialudenberg')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_danganro_celestialudenberg')
        local new_numerator3, new_denominator3 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds3, 'j_danganro_celestialudenberg')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2, new_numerator3, new_denominator3}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                return {
                    chips = 40
                }
            elseif true then
                return {
                    mult = 20
                }
            elseif true then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 10
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(10), colour = G.C.MONEY})
                        return true
                    end
                }
            end
        end
    end
}