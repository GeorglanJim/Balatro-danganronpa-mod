
SMODS.Joker{ --Genocide Jack
    key = "genocidejack",
    config = {
        extra = {
            repetitions0 = 3,
            repetitions = 3
        }
    },
    loc_txt = {
        ['name'] = 'Genocide Jack',
        ['text'] = {
            [1] = 'Retrigger {C:attention}Jacks{} 3 times',
            [2] = 'when {C:attention}played{} and when {C:attention}in hand{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["danganro_danganro_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            
            or args.source == 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and G.GAME.pool_flags.danganro_Toko
    end,
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card:get_id() == 11 then
                return {
                    repetitions = 3,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.repetition and not context.cardarea == G.hand and context.end_of_round and (next(context.card_effects[1]) or #context.card_effects > 1)  then
            if context.other_card:get_id() == 11 then
                return {
                    repetitions = 3,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}