
SMODS.Joker{ --Aoi Asahina
    key = "aoiasahina",
    config = {
        extra = {
            Aoi = 100
        }
    },
    loc_txt = {
        ['name'] = 'Aoi Asahina',
        ['text'] = {
            [1] = '{C:red}+100 Mult{}, reduces',
            [2] = 'by {C:red}10{} every round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["danganro_mycustom_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Aoi}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = card.ability.extra.Aoi
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                func = function()
                    card.ability.extra.Aoi = math.max(0, (card.ability.extra.Aoi) - 10)
                    return true
                end
            }
        end
    end
}