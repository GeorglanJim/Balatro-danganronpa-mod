
SMODS.Joker{ --Yasuhiro Hagakure
    key = "yasuhirohagakure",
    config = {
        extra = {
            set_probability0 = 100000
        }
    },
    loc_txt = {
        ['name'] = 'Yasuhiro Hagakure',
        ['text'] = {
            [1] = '{C:attention}Guarantees{} all {C:green}probabilities{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["danganro_danganro_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.fix_probability  then
            local numerator, denominator = context.numerator, context.denominator
            numerator = 100000
            return {
                numerator = numerator, 
                denominator = denominator
            }
        end
    end
}